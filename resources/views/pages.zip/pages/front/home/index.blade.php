@extends('layouts.front')

@section('content_fe')
    @include('pages.front.home.fact_data')

    @include('pages.front.home.book_recently')
@endsection
